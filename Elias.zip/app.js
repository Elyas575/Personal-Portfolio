const links = document.querySelectorAll('.element')
const sections = document.querySelectorAll('section');
console.log(sections)


let activeLink = 0;

links.forEach((link,i) => {
    link.addEventListener('click', () => {
        if(activeLink !=i){

            links[activeLink].classList.remove('active');
            link.classList.add('active');
            sections[activeLink].classList.remove('active');
            console.log(sections)

            setTimeout(() => {
                activeLink = i;
                sections[i].classList.add('active');
            }, 1000);
       
        }
    })
})